package projeto.exemplo;


public abstract class Fisica extends Pessoa {
  private String cpf;

  public Fisica(String cpf) {
    System.out.println("Construindo Fisica");
    this.cpf = cpf;
  }

  public String toString() {
    return cpf;
  }

  public String getCpf() {
    return cpf;
  }

  public void setCpf(String cpf) {
    this.cpf = cpf;
  }
}
