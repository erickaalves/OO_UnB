public class Telefone {
    private int ddd;
    private int numero;

    public double getDDD() { return ddd; }
	  public void setDDD(double ddd) { this.ddd = ddd; }
    
    public double getNumero() { return numero; }
	  public void setNumero(double numero) { this.numero = numero; }
    
    
    public Telefone(ddd, numero) {
      this.ddd = ddd;
      this.numero = numero;
    }
}
