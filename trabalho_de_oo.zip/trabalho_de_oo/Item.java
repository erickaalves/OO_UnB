public abstract class Item {
  private String nome;

  public Item(String nome, int quantidade, float valor) {
    System.out.println("Construindo Item");
    this.nome = nome;
    this.quantidade = quantidade;
    this.valor = valor;
  }

  public String toString() {
    return nome;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getQuantidade() {
    return quantidade;
  }

  public void setQuantidade(String quantidade) {
    this.quantidade = quantidade;
  }


  public String getValor() {
    return valor;
  }

  public void setValor(String valor) {
    this.valor = valor;
  }
}
