public abstract class Cliente {
  private String identificador;

  public Cliente(String identificador) {
    System.out.println("Construindo Cliente");
    this.identificador = identificador;
  }

  public String toString() {
    return identificador;
  }

  public String getIdentificador() {
    return identificador;
  }

  public void setIdentificador(String identificador) {
    this.identificador = identificador;
  }
}
