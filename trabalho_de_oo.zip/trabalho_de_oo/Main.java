public class Main {
  public static void main() {
  System.out.println('Main');
 }
}
