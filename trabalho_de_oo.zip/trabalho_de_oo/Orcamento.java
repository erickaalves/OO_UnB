public abstract class Orcamento {
  private String nome;
  private String tipo;
  private float receita;
  private float despesa;
  private float valorTotal;
  private ArrayList<Item> items;

  public Orcamento(String nome, String tipo, float receita, float despesa, float valorTotal) {
    System.out.println("Construindo Orcamento");
    this.nome = nome;
    this.tipo = tipo;
    this.receita = receita;
    this.despesa = despesa;
    this.valorTotal = valorTotal;
  }

  public String toString() {
    return nome;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public String getReceita() {
    return receita;
  }

  public void setReceita(String receita) {
    this.receita = receita;
  }

  public String getDespesa() {
    return despesa;
  }

  public void setDespesa(String despesa) {
    this.despesa = despesa;
  }

  public float calculaValorTotal() {
    float valorTotal = 0
    System.out.println("Calculando valor total");
    return valorTotal;
  }
}
