public abstract class Juridica extends Pessoa {
  private String cnpj;

  public Juridica(String cnpj) {
    System.out.println("Construindo Juridica");
    this.cnpj = cnpj;
  }

  public String toString() {
    return cnpj;
  }

  public String getCnpj() {
    return cnpj;
  }

  public void setCnpj(String cnpj) {
    this.cnpj = cnpj;
  }
}
